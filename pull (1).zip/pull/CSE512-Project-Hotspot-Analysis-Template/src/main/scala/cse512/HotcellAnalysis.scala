package cse512

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.sum
import org.apache.spark.sql.functions.desc
import org.apache.spark.sql.functions.asc
import scala.math.sqrt
import scala.math.min
import scala.math.max


object HotcellAnalysis {
  Logger.getLogger("org.spark_project").setLevel(Level.WARN)
  Logger.getLogger("org.apache").setLevel(Level.WARN)
  Logger.getLogger("akka").setLevel(Level.WARN)
  Logger.getLogger("com").setLevel(Level.WARN)


def runHotcellAnalysis(spark: SparkSession, pointPath: String): DataFrame =
{
  // Load the original data from a data source
  var pickupInfo = spark.read.format("com.databricks.spark.csv").option("delimiter",";").option("header","false").load(pointPath);
  pickupInfo.createOrReplaceTempView("nyctaxitrips")
  //pickupInfo.show()

  // Assign cell coordinates based on pickup points
  spark.udf.register("CalculateX",(pickupPoint: String)=>((
    HotcellUtils.CalculateCoordinate(pickupPoint, 0)
    )))
  spark.udf.register("CalculateY",(pickupPoint: String)=>((
    HotcellUtils.CalculateCoordinate(pickupPoint, 1)
    )))
  spark.udf.register("CalculateZ",(pickupTime: String)=>((
    HotcellUtils.CalculateCoordinate(pickupTime, 2)
    )))

  //pickupInfo = spark.sql("select CalculateX(nyctaxitrips._c5),CalculateY(nyctaxitrips._c5), CalculateZ(nyctaxitrips._c1) from nyctaxitrips").persist()
  //var newCoordinateName = Seq("x", "y", "z")
  //pickupInfo = pickupInfo.toDF(newCoordinateName:_*)
  //pickupInfo.show()
  // Define the min and max of x, y, z

  val minX = -74.50/HotcellUtils.coordinateStep
  val maxX = -73.70/HotcellUtils.coordinateStep
  val minY = 40.50/HotcellUtils.coordinateStep
  val maxY = 40.90/HotcellUtils.coordinateStep
  val minZ = 1
  val maxZ = 31
  val numCells = (maxX - minX + 1)*(maxY - minY + 1)*(maxZ - minZ + 1)

 // YOU NEED TO CHANGE THIS PART
//	  pickupInfo.createOrReplaceTempView("pickupInfo")

	  var sumInfo = spark.sql("SELECT x,y,z, count(*) as count from (select CalculateX(nyctaxitrips._c5) as x,CalculateY(nyctaxitrips._c5) as y, CalculateZ(nyctaxitrips._c1) as z from nyctaxitrips) as pickupInfo group by x,y,z").persist()
	sumInfo.createOrReplaceTempView("sumInfo")

  	val sumWij = sumInfo.agg(sum("count")).first.getLong(0)

	 def squareEntry(num:Int):Int={return num*num}
  	 spark.udf.register("squareEntry", (num:Int) => (squareEntry(num)) )
  	 var sqSum = spark.sql("select x,y,z,count,squareEntry(sumInfo.count) as squareCount from sumInfo").agg(sum("squareCount")).first.getLong(0)

	val mean = sumWij/numCells

	val S = sqrt( sqSum/numCells - (mean*mean) )


	def getisOrdFunc(wijxjSum:Double, totalNeighbours:Double, S:Double, numCells:Double, mean:Double):Double = {
	
		val num = wijxjSum - mean*totalNeighbours
		val den = S*sqrt( (numCells*totalNeighbours - (totalNeighbours*totalNeighbours)  )/ (numCells-1) ) 
		if (den == 0.0){return 0.0}
		return num/den
	}

	def getNeighbours(x:Int, y:Int, z:Int): Double = {
		var neighbours=0; 
		for(tX <- max(x-1,minX.toInt) to min(x+1,maxX.toInt)){ 
			for(tY <- max(y-1,minY.toInt) to min(y+1,maxY.toInt)){ 
				for(tZ <- max(z-1,minZ.toInt) to min(z+1,maxZ.toInt)){ 
						neighbours=neighbours+1
				}			
			}		
		}
		return neighbours.toDouble
	}

	spark.udf.register("getNeighbours", (x:Int, y:Int, z:Int) => (getNeighbours(x,y,z)) );
	spark.udf.register("getisOrdFunc", (wijxjSum:Double, totalNeighbours:Double) => (getisOrdFunc(wijxjSum, totalNeighbours, S, numCells.toInt, mean)) )

	return  spark.sql("select c.x,c.y,c.z, c.totalNeighbours, getisOrdFunc(c.wijxjSum, c.totalNeighbours) as getisOrd  from (select a.x as x,a.y as y,a.z as z, sum(b.count) as wijxjSum, count(*) as presentNeighbours, getNeighbours(a.x,a.y,a.z) as totalNeighbours from sumInfo as a, sumInfo as b where b.x>= a.x-1 and b.x<=a.x+1 and b.y>=a.y-1 and b.y<=a.y+1 and b.z>=a.z-1 and b.z<=a.z+1 group by a.x,a.y,a.z) as c order by getisOrd desc").drop("totalNeighbours", "getisOrd")


  //return getisOrdView // YOU NEED TO CHANGE THIS PART

}
}

	





