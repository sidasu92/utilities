package cse512
import scala.math._

object HotzoneUtils {

  def ST_Contains(queryRectangle: String, pointString: String ): Boolean = {
    // YOU NEED TO CHANGE THIS PART
	var xy = pointString.split(",")
	var px = xy(0).toDouble
	var py = xy(1).toDouble
	
	var recXY = queryRectangle.split(",")
	var recLX = recXY(0).toDouble
	var recLY = recXY(1).toDouble
	var recTX = recXY(2).toDouble
	var recTY = recXY(3).toDouble
	
	var minX = min(recLX, recTX)
	var minY = min(recLY, recTY)
	var maxX = max(recLX, recTX)
	var maxY = max(recLY, recTY)
	if (px<minX || py<minY || px>maxX || py>maxY){
	return 	false
	}
	else{
		return true
	}

    
  }

  // YOU NEED TO CHANGE THIS PART

}







